// Definindo variáveis utilizadas no projeto
let tempo = 10;
let pontoSecreto;
let jogoComecou = false;
let jogoFinalizado = false;
let sucesso = false;

let pontoVelocidade;

function setup() {
  createCanvas(400, 400);
  textAlign(CENTER, CENTER);
  frameRate(30);

  // O ponto secreto inicia em uma posição aleatoria
  pontoSecreto = createVector(random(50, 350), random(50, 350));
  pontoVelocidade = createVector(random(-1, 1), random(-1, 1));
}

// Definindo telas inicial e final do projeto
function draw() {
  if (!jogoComecou) {
    telaInicial();
  } else if (jogoFinalizado) {
    telaFinal();
  } else {
    jogar();
  }
}

// Tela inicial - instruções
function telaInicial() {
  background("green");
  fill(255);
  textSize(24);
  text("🔥 Salve a floresta! 🔥", width / 2, 60);
  textSize(16);
  text("Use o mouse para mover o fogo.", width / 2, 120);
  text("Quanto mais próximo do ponto escondido,", width / 2, 150);
  text("menor o fogo fica!", width / 2, 170);
  text("Você tem 10 segundos!", width / 2, 200);
  text("Clique para começar!", width / 2, 250);
}

// O jogo começa quando o mouse é pressionado
function mousePressed() {
  if (!jogoComecou) {
    jogoComecou = true;
    frameCount = 0;
  }
}

// Desenhando a floresta
function jogar() {
  background("green");

  textSize(24);
  for (let x = 40; x < width; x += 80) {
    for (let y = 60; y < height; y += 80) {
      text("🌳", x, y);
    }
  }

  // Contagem regressiva do tempo
  if (frameCount % 30 === 0 && tempo > 0) {
    tempo--;
  }

  fill(255);
  textSize(20);
  text("Tempo: " + tempo, width / 2, 20);

  // Fazendo o ponto secreto deslizar pela tela
  pontoSecreto.add(pontoVelocidade);
  pontoSecreto.x = constrain(pontoSecreto.x, 10, width - 10);
  pontoSecreto.y = constrain(pontoSecreto.y, 10, height - 10);

  // Inverter direção se bater nas bordas
  if (pontoSecreto.x <= 10 || pontoSecreto.x >= width - 10) {
    pontoVelocidade.x *= -1;
  }
  if (pontoSecreto.y <= 10 || pontoSecreto.y >= height - 10) {
    pontoVelocidade.y *= -1;
  }

  // Fogo segue o mouse
  let d = dist(mouseX, mouseY, pontoSecreto.x, pontoSecreto.y);

  // Quanto mais longe, maior o fogo
  let tamanhoFogo = map(d, 0, 400, 0, 400, true);
  textSize(tamanhoFogo);
  text("🔥", mouseX, mouseY);

  // Verificando se encontrou o ponto secreto
  if (d < 15) {
    sucesso = true;
    jogoFinalizado = true;
  }

  // Tempo acabou
  if (tempo <= 0) {
    sucesso = false;
    jogoFinalizado = true;
  }
}

// Tela final - fim do jogo
function telaFinal() {
  background("green");
  fill(255);
  textSize(22);
  if (sucesso) {
    text("🎉 Parabéns! Você salvou a floresta! 🎉", width / 2, height / 2);
  } else {
    //fill('red');
    text("⏱️ Tempo Esgotado!", width / 2, height / 2);
  }

  // Jogar novamente
  textSize(16);
  fill(255);
  text("Atualize a página para jogar novamente.", width / 2, height / 2 + 40);
}
